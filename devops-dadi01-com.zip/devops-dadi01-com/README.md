#大地零一
#### web
* [elasticsearch_head](http://11.11.0.24:9100) 
* [phpMyAdmin](http://phpmyadmin.dd01.fun) 
* [deploy](http://deploy.dd01.fun)


#### Service
* Mysql 11.11.0.27:3306
* Redis 11.11.0.27:6379
* mongo 11.11.0.27:27107
* memcached 11.11.0.27:11211
* ssdb 11.11.0.27:6380
* elasticsearch 11.11.0.27:9200
* kibana 11.11.0.27:11211



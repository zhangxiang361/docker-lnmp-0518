## 使用说明


### 使用前提
* docker
* docker-compose

### 使用步骤

* 将项目代码clone到本地
```
git clone ssh://git@gitlab.dadi01.com:28/web/devops-dadi01-com.git
```
* 进入devops目录
```
cd devops
```
* 复制.env.example，命名为.env
```
cp .env.example  .env
```
* 修改.env文件
```
vim .env
```
* 启动
```
docker-compose up -d
```


### 配置（.env文件)

```yaml
# 开发目录，需要每个人自己配置
DEV_WORKPLACE=/www/

#PHP版本，暂时只有71和72选择
PHP_VERSION=71
```

### 使用命令

#### 构建
    docker-compose build [image]
    
其中[image]如果不指定则构建所有镜像，image可以多个，空格分隔
#### 运行
    docker-compose up [-d] [container]
    
其中 -d指定是否后台运行 image如果不指定则运行所有容器，image可以多个，空格分隔。

___如果镜像未构建，会自动构建镜像并运行容器___
#### 进入容器
    docker-compose exec php bash
    
其中php可以替换成其他容器，容器名和docker-compose.yml的容器名一致。

进入nginx需要改为```docker-compose exec nginx /bin/sh```
#### 停止容器
    docker-compose stop [container]
#### 停止并删除容器
    docker-compose down [options]
#### 查看日志
    docker-compose logs [container]
    
#### 查看容器列表
    docker-compose ps
#### 查看镜像列表
    docker-compose images
    
### 特殊目录说明

* conf 各类配置
* conf/conf.d 站点配置
* data 动态数据目录
* log 日志
* www 测试目录（暂不使用）


### todo
1. 项目nginx配置暂时没有完全提供，需要各个项目自己添加。

2. 项目自定义配置.env,暂时只有两项，考虑到本地端口占用情况，是否需要提供每个host端口的自定义配置。

3. php扩展，现在只提供了目前所需的扩展，如果需要增加扩展请联系
维护者（junyiye@hk01.com）
4. 数据服务，目前提供mysql和redis，如果需要其他如MongoDB、EFK，请提出。


### docker-compose  安装
```$xslt
sudo curl -L https://github.com/docker/compose/releases/download/1.21.2/docker-compose-$(uname -s)-$(uname -m) -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
```



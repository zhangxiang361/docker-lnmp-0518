<?php
echo 'Site 1<br />';
phpinfo();

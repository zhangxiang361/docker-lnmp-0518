#/bin/bash
mkdir -p /data/jenkins_home
chown dadi:dadi /data/jenkins_home

docker run -d --name jenkins-ci \
  --privileged=true \
  -p 9090:8080 -p 50000:50000  \
  -v /data/jenkins_home:/var/jenkins_home \
  -v /usr/share/zoneinfo/Asia/Shanghai:/etc/localtime \
  -v /etc/timezone:/etc/timezone \
    jenkinsci/jenkins:lts
#/bin/bash
sudo docker run --name elasticsearch-head -d -p 9100:9100 mobz/elasticsearch-head:5

 #/bin/bash
 docker run -d -p 8300:8300 --name web-doc -v /www/web/swagger-doc:/usr/src/app -w /usr/src/app node:8 npm start

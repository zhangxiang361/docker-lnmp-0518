#/bin/bash
#sudo docker run --name web -p 80:80 -v /usr/local/docker/nginx/sites-enabled:/etc/nginx/sites-enabled -v /usr/local/docker/php/:/etc/php  -d ubuntu:16.04
sudo docker run --name dadi_web -d ubuntu:16.04

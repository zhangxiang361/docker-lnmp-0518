!#/bin/bash
mkdir -p /usr/local/docker/logstash/logs
mkdir -p /usr/local/docker/logstash/config
mkdir -p /usr/local/docker/logstash/pipeline
mkdir -p /usr/local/docker/logstash/data

docker run -d --name logstash -p 5044:5044 -p 9600:9600 \
        -v /usr/local/docker/logstash/config:/usr/share/logstash/config \
        -v /usr/local/docker/logstash/pipeline:/usr/share/logstash/pipeline \
        docker.elastic.co/logstash/logstash:5.6.10

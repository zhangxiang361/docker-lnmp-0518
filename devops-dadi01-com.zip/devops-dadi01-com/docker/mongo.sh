#/bin/bash
sudo docker run --name mongo -p 27017:27017 -v /usr/local/docker/mongo/db:/data/db -d mongo:latest

#/bin/bash
docker run --name web-kibana -p 5601:5601 \
        -e ELASTICSEARCH_URL=http://11.11.0.25:9200 \
        -d kibana

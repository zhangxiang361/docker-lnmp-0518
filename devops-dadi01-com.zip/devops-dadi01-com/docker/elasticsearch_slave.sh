#/bin/bash
docker run -d --name es2 -p 9200:9200 -p 9300:9300 \
    -v /usr/local/docker/elasticsearch/es2.yml:/usr/share/elasticsearch/config/elasticsearch.yml \
    -v /usr/local/docker/elasticsearch/data2:/usr/share/elasticsearch/data \
    elasticsearch:5.6.4


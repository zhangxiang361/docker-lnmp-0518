#/bin/bash
docker run --name gopub -e MYSQL_HOST=11.11.0.27 -e MYSQL_PORT=3306  \
    -e MYSQL_USER=gopub -e MYSQL_PASS=UjQxAIGlJtzyETOX -e MYSQL_DB=deploy \
    -p 8192:8192 --restart always -d lc13579443/gopub:latest

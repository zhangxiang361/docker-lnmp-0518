#/bin/bash
mkdir -p /usr/local/docker/redis/conf
mkdir -p /usr/local/docker/redis/data
docker run --name redis \
    -p 6379:6379 \
    -e ALLOW_EMPTY_PASSWORD=yes \
    -d redis:latest \

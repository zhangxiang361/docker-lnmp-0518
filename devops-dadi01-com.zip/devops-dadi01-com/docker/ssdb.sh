#/bin/bash
sudo docker run --name ssdb -p 6380:8888 -d wendal/ssdb:latest

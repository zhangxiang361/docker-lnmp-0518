mkdir -p /usr/local/docker/nginx/conf.d
docker run --name web-nginx -p 80:80 -d \
    -v /www/web:/www/web:ro \
    -v /usr/local/docker/nginx/conf.d:/etc/nginx/conf.d:ro \
    --link web-php:php \
    --link gopub:gopub \
    --link web-doc:doc \
    --link web-kibana:kibana \
    nginx


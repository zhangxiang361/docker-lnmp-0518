#大地零一开发环境部署
#### 构建docker
~~~
工作目录：/www/web
配置目录: /usr/local/dorcker

sh web-php-fpm.sh
sh nginx.sh

将config/nginx/对应域名下的站点配置拷贝到本地 /usr/local/dorcker/nginx/conf.d/

➜  docker ps -a
CONTAINER ID        IMAGE               COMMAND                  CREATED             STATUS                       PORTS                NAMES
d03366e7bec1        nginx               "nginx -g 'daemon of…"   About an hour ago   Exited (255) 4 seconds ago   0.0.0.0:80->80/tcp   web-nginx
9db54507d368        dadi01/php:7.1      "docker-php-entrypoi…"   About an hour ago   Exited (255) 4 seconds ago   9000/tcp             web-php
~~~




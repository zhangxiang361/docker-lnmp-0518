#/bin/bash
docker run --name web-php -d -v /www/web:/www/web:rw dadi01/php:7.1

#/bin/bash
mkdir -p /usr/local/docker/fluentd/log
mkdir -p /usr/local/docker/fluentd/etc
docker run -d --name fluentd -p 24224:24224 -p 24224:24224/udp \
	-v /usr/local/docker/fluentd/etc:/fluentd/etc \
	-v /usr/local/docker/fluentd/log:/fluentd/log \
	fluent/fluentd

#/bin/bash
mkdir -p /usr/local/docker/mysql/data
mkdir -p /usr/local/docker/mysql/conf
docker run --name mysql -p 3306:3306 \
    -v /usr/local/docker/mysql/conf:/etc/mysql/conf.d \
    -v /usr/local/docker/mysql/data:/var/lib/mysql \
    -e MYSQL_ROOT_PASSWORD=dadi123456 -d mysql:5.7 \
    --character-set-server=utf8 --collation-server=utf8_general_ci
